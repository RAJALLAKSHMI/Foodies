var React = require('react');
var ListItem = require('./list.jsx');
var List=React.createClass({
  render:function(){
    let jsonarray=this.props.data;
    if(jsonarray.length>0)
    {
    var ListItems=jsonarray.map(function(item){
      return <ListItem key={arguments[1]} id={item.restaurant.R.res_id} name={item.restaurant.name} address = {item.restaurant.location.address} image = {item.restaurant.featured_image} rating = {item.restaurant.user_rating.aggregate_rating}/>;
      });
      return (<div className="ui three stackable cards" style={{margin : 10}}>{ListItems}</div>);
    }
    else {
      return (<h1>Select some id and cuisine</h1>);
    }
  }
});
module.exports = List;
