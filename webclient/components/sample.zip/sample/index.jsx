// import React from 'react';
// import ReactDOM from 'react-dom';
// import ChildComponent from './childComponent.jsx';
// import Child1 from './secchildComponent.jsx';
//
// class ParentComponent extends React.Component {
//     constructor() {
//         super();
//         this.clickfn= this.clickfn.bind(this);
//     }
//     clickfn()
//     {
//        this.props.clickfn();
//     }
//     render() {
//         return (
//             <div>
//             <h2>hello from child part {this.props.name}</h2>
//             <Child1 name={this.props.name}/>
//             <ChildComponent name="childpart"/>
//              <button onClick={this.clickfn}>changebutton</button>
//             </div>
//         );
//     }
// }
//
// export default ParentComponent;
