// import React from 'react';
// import ReactDOM from 'react-dom';
//
// class GrandComponent extends React.Component {
//     constructor() {
//         super();
//
//     }
//     render() {
//         var color = {color : "blue"}
//         return (
//             <div>
//                 <h2 style={color}>Hello from {this.props.name} of age is {this.props.age}</h2>
//             </div>
//         )
//     }
// }
//
// export default GrandComponent;
