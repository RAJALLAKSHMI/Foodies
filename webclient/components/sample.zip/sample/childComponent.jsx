// import React from 'react';
// import ReactDOM from 'react-dom';
// import GrandComponent from './GrandComponent.jsx';
//
// class ChildComponent extends React.Component {
//     constructor() {
//         super();
//
//     }
//
//
//     render() {
//         return (
//             <div>
//                 <h2>Hello from ChildComponent {this.props.name}</h2>
//                 <GrandComponent name="grany" age="50"/>
//               </div>
//
//         )
//     }
// }
//
// export default ChildComponent;
