// import React from 'react';
// import ReactDOM from 'react-dom';
// class secchildComponent extends React.Component {
//     constructor() {
//         super();
//     }
//     render() {
//         return (
//             <div>
//                 <h2>Hello from {this.props.name}</h2>
//             </div>
//         );
//     }
// }
// export default secchildComponent;
