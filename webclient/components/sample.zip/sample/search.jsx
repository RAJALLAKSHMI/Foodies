import React from 'react';
import ReactDOM from 'react-dom';
// import Child from './components/sample';

class search extends React.Component {
    constructor() {
        super();
        this.state = {
            "id": "",
            "cuisine": ""
        }
        this.Clickfn = this.Clickfn.bind(this);
        this.onChange = this.onChange.bind(this);

    }
    Clickfn(id, cuisine)
    {
        this.props.change(id, cuisine);
    }
    onChange(name)
    {
        this.setState({
            [name.target.name]: name.target.value
        });
    }
    render() {
        return (
            <div>
                <form>
                    <input type="text" name="cityid" placeholder="enter cityid" onChange={this.onChange}/>
                    <input type="text" name="cuisine" placeholder="enter cuisine" onChange={this.onChange}/>
                </form>
                <button type="button" onClick={this.Clickfn.bind(this, this.state.id, this.state.cuisine)}>search</button>
            </div>
        )

    }
}
export default search;
