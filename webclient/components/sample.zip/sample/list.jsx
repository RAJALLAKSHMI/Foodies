var React = require('react');
var ListItem=React.createClass({
  render:function(){
    let img=this.props.image;
    return (
                    <div className="card">
                              <div className="image">
                                  <img src={img} alt="restaurant image" style={{height:200}}/>
                              </div>
                              <div className="content">
                                  <div className="header">{this.props.id} : {this.props.name}</div>
                                  <div className="description">{this.props.address} </div>
                              </div>
                              <div className="extra content">
                                  <a>
                                      <i className="smile icon"></i>{this.props.rating}
                                  </a>
                              </div>
                          </div>

                        );
}
});
module.exports=ListItem;
